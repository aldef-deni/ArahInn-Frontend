import { clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs) {
  return twMerge(clsx(inputs))
}

// Harga otomatis: IDR (Bahasa Indonesia) / USD kurs terkini (English).
// Lihat src/utils/currency.js — konversi berdasarkan i18n.language.
import { formatMoney, loadFxRate, getUsdIdr } from './currency'
export { formatMoney, loadFxRate, getUsdIdr }
export const formatRupiah = (amount) => formatMoney(amount)

export const formatDate = (date, opts = {}) =>
  new Intl.DateTimeFormat('id-ID', { year: 'numeric', month: 'long', day: 'numeric', ...opts }).format(new Date(date))

export const formatDateShort = (date) =>
  new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(date))

export const formatDateTime = (date) =>
  new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(date))

export const diffDays = (a, b) => {
  const d1 = new Date(a); const d2 = new Date(b)
  return Math.round((d2 - d1) / (1000 * 60 * 60 * 24))
}

export const statusBadgeClass = (status) => ({
  paid      : 'badge-paid',
  pending   : 'badge-pending',
  issued    : 'badge-issued',
  canceled  : 'badge-canceled',
  refunded  : 'badge-refunded',
  rescheduled: 'badge-issued',
}[status] || 'badge-pending')

export const statusLabel = (status) => ({
  paid      : 'Dibayar',
  pending   : 'Menunggu',
  issued    : 'Dikonfirmasi',
  canceled  : 'Dibatalkan',
  refunded  : 'Dikembalikan',
  rescheduled: 'Dijadwalkan Ulang',
}[status] || status)

export const roleLabel = (role) => ({
  superadmin     : 'Super Admin',
  owner          : 'Pemilik Hotel',
  admin_property : 'Admin Properti',
  admin          : 'Market Manager',
  finance        : 'Keuangan',
  design_interior: 'Design Interior',
  user           : 'Pengguna',
}[role] || role)

export const generateBookingCode = () =>
  'OTA' + Math.random().toString(36).slice(2, 9).toUpperCase()

export const truncate = (str, n = 80) =>
  str?.length > n ? str.slice(0, n) + '...' : str

export { slugify, categorySlug, hotelDetailUrl } from './slugify'

export function getImageUrl(path) {
  if (!path) return null
  // Handle object format {path: "...", category: "..."} stored by the hotel registration endpoint
  if (typeof path === 'object') return getImageUrl(path.path ?? null)
  if (typeof path !== 'string') return null
  if (/^(https?:\/\/|blob:|data:)/.test(path)) return path
  const apiUrl = import.meta.env.VITE_API_URL || ''
  const base = apiUrl.replace(/\/api(\/v\d+)?\/?$/, '').replace(/\/$/, '')
  return `${base}/${path.replace(/^\//, '')}`
}
